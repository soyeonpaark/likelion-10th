export type RestProps = {
  [key: string]: unknown;
};
